public class FriendList {
}
