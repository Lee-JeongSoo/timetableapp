package com.course.timetableapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class CompareActivity extends AppCompatActivity {
    private static final String TAG = "PersonDatabase";
    CompareFriendsAdapter adapter;
    FriendsDatabase database;
    ArrayList<FriendsCheck> result;

    private Button gobackBtn;
    private Button gonextBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare);
        gobackBtn = findViewById(R.id.goback_btn);
        gonextBtn = findViewById(R.id.gonext_btn);
        RecyclerView recyclerView = findViewById(R.id.select_friends_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        gobackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent = new Intent(CompareActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // open database
        if (database != null) {
            database.close();
            database = null;
        }

        database = FriendsDatabase.getInstance(this);
        boolean isOpen = database.open();
        if (isOpen) {
            Log.d(TAG, " database is open.");
        } else {
            Log.d(TAG, "database is not open.");
        }

        adapter = new CompareFriendsAdapter();
        recyclerView.setAdapter(adapter);
        result = selectAll_();
        adapter.setItems(result);
        gonextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<FriendsCheck> selectedFriends = new ArrayList<>();

                for (FriendsCheck friend_ : result) {
                    if (friend_.isSelected()) {

                        selectedFriends.add(friend_);
                    }
                }
                Log.d(TAG, Integer.toString(result.size()));
                Log.d(TAG, Integer.toString(selectedFriends.size()));
                if (selectedFriends.size() >= 1) {
                    // 선택된 항목들의 정보 처리
                    for (FriendsCheck selectedFriend : selectedFriends) {
                        int userId = selectedFriend.getID();
                        String userName = selectedFriend.getName();
                        // 선택된 항목의 정보 활용
                        Log.d(TAG, "User ID: " + userId);
                        Log.d(TAG, "User Name: " + userName);
                    }
//// CompareActivity에서 선택된 friendsList를 전달하기 전에 직렬화하여 문자열로 변환
//                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
//                    ObjectOutputStream oos = null;
//                    String serializedFriends = null;
//                    try {
//                        oos = new ObjectOutputStream(bos);
//                        oos.writeObject(selectedFriends);
//                        oos.flush();
//
//                        // ByteArrayOutputStream을 닫지 않고 문자열로 변환
//                        byte[] byteArray = bos.toByteArray();
//                        serializedFriends = Base64.encodeToString(byteArray, Base64.DEFAULT);
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    } finally {
//                        try {
//                            if (oos != null) {
//                                oos.close();
//                            }
//                            bos.close();
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                    Intent intent = new Intent(CompareActivity.this, CompareResultActivity.class);
//// 직렬화된 친구 목록을 문자열로 변환하여 "selected_friends" 키로 설정
//                    intent.putExtra("selected_friends", serializedFriends);
                    Intent intent = new Intent(CompareActivity.this, CompareResultActivity.class);
                    intent.putParcelableArrayListExtra("selected_friends", selectedFriends);
                    startActivity(intent);
                } else {
                    Toast.makeText(CompareActivity.this, "1명 이상의 친구를 선택해주세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public ArrayList<FriendsCheck> selectAll_() {
        ArrayList<FriendsCheck> result = database.selectAll_();
        Toast.makeText(getApplicationContext(), "비교할 친구를 선택해주세요", Toast.LENGTH_LONG).show();
        return result;
    }

}