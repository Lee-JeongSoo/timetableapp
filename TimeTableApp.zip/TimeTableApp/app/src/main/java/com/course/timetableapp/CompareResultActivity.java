package com.course.timetableapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class CompareResultActivity extends AppCompatActivity {
    private static final String TAG = "TimeTableDatabase";
    private Button gobackBtn;
    private Button addPlanBtn;
    TimeTableDatabase database;
    ArrayList<Integer> selectedFriendsId;
    ArrayList<FriendsCheck> selectedFriends;
    private String title="나";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_compare_result);

        gobackBtn = findViewById(R.id.goback_btn);

        TextView title_ = findViewById(R.id.Username);

        if (database != null) {
            database.close();
            database = null;
        }

        database = TimeTableDatabase.getInstance(this);
        boolean isOpen = database.open();
        if (isOpen) {
            Log.d(TAG, " database is open.");
        } else {
            Log.d(TAG, "database is not open.");
        }
        loadTimetable(-2);
Log.d(TAG, "기본사용자 호출완료");
        gobackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent1 = new Intent(CompareResultActivity.this, MainActivity.class);
                startActivity(intent1);
            }
        });
        Intent intent = getIntent();
        selectedFriends = intent.getParcelableArrayListExtra("selected_friends");
        if (selectedFriends != null) {
            for (FriendsCheck friend : selectedFriends) {
                int userId = friend.getID();
                String userName = friend.getName();
                loadTimetable(userId);
                title=title+", "+userName;
                // 필요한 작업 수행
                Log.d(TAG, "User ID: " + userId);
                Log.d(TAG, "User Name: " + userName);
                Log.d(TAG, "title: " + title);
            }
        } else {
            Toast.makeText(getApplicationContext(), "전달된 친구 목록이 없습니다.", Toast.LENGTH_LONG).show();
        }
        title_.setText(title);
//        Log.d(TAG, "111111");
//        String serializedFriends = intent.getStringExtra("selected_friends");
//        Log.d(TAG, "22222");
//        if (serializedFriends != null) {
//            Log.d(TAG, "33333");
//            byte[] serializedBytes = Base64.decode(serializedFriends, Base64.DEFAULT);
//            Log.d(TAG, "33333");
//            ArrayList<FriendsCheck> selectedFriends = null;
//            Log.d(TAG, "33333");
//            try {
//                ByteArrayInputStream bis = new ByteArrayInputStream(serializedBytes);
//                ObjectInputStream ois = new ObjectInputStream(bis);
//                selectedFriends = (ArrayList<FriendsCheck>) ois.readObject();
//                ois.close();
//                bis.close();
//                Log.d(TAG, "4444");
//            } catch (IOException e) {
//                e.printStackTrace();
//            } catch (ClassNotFoundException e) {
//                e.printStackTrace();
//            }
//            Log.d(TAG, "55555");
//            if (selectedFriends != null) {
//                Log.d(TAG, "666666");
//                selectedFriendsId = new ArrayList<>();
//                Log.d(TAG, "77777");
//                for (FriendsCheck friend : selectedFriends) {
//                    int userId = friend.getID();
//                    String userName = friend.getName();
//                    Log.d(TAG, "8888");
//                    title = title + ", " + userName;
//                    selectedFriendsId.add(userId);
//                    // 필요한 작업 수행
//                    Log.d(TAG, "User ID: " + userId);
//                    Log.d(TAG, "User Name: " + userName);
//                }
//                Log.d(TAG, selectedFriendsId.size()+"");
//                if (selectedFriendsId != null) {
//                    for (Integer userId : selectedFriendsId) {
//                        loadTimetable(userId);
//                    }
//                }
//            } else {
//                Toast.makeText(getApplicationContext(), "알 수 없는 오류가 발생했습니다.", Toast.LENGTH_LONG).show();
//            }
//        } else {
//            Toast.makeText(getApplicationContext(), "전달된 친구 목록이 없습니다.", Toast.LENGTH_LONG).show();
//        }

    }

    private void loadTimetable(int ID) {
        // 시간표 데이터를 가져오는 로직을 구현합니다.
        //기본 사용자는 -2를 키로 한다.
        ArrayList<TimeTable> timetableList = database.selectAll(ID);
        Log.d(TAG, "timetable size is : "+timetableList.size());
        if(timetableList==null) return;
        // 가져온 시간표 데이터를 텍스트뷰에 설정합니다.
        for (TimeTable timetable : timetableList) {
            String textViewDayId = null;
            // 시간과 요일에 해당하는 텍스트뷰 ID를 찾습니다. (예: R.id.monday_9am)
            switch(timetable.getDay()) {
                case "월":
                    textViewDayId = "monday";
                    break;
                case "화":
                    textViewDayId = "tuesday";
                    break;
                case "수":
                    textViewDayId = "wednesday";
                    break;
                case "목":
                    textViewDayId = "thursday";
                    break;
                case "금":
                    textViewDayId = "friday";
                    break;
                case "토":
                    textViewDayId = "seturday";
                    break;
                case "일":
                    textViewDayId = "sunday";
                    break;
            }
            int hour = Integer.valueOf(timetable.getStarttime());
            while(hour<Integer.valueOf(timetable.getEndtime())) {
                String textViewId = textViewDayId + Integer.toString(hour);
//                Log.d("CHECKVALUE", textViewId+" "+timetable.getStarttime()+timetable.getEndtime());
                int resId = getResources().getIdentifier(textViewId, "id", getPackageName());

                if (resId != 0) {
                    TextView textView = findViewById(resId);
                    //textView.setText(timetable.getName());
                    textView.setBackgroundResource(R.drawable.fill_cell);
                }
                if(hour%100==30) hour+=70;
                else hour +=30;
            }
        }
    }
}