package com.course.timetableapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rv_friends;
    //private FriendsAdapter friendsAdapter;
    private List<String> friendsList;
    private Button editBtn;
    private Button compareBtn;
    private Button checkFriendsBtn;
    private Button myTimeTableBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        compareBtn = findViewById(R.id.compare_btn);
        checkFriendsBtn = findViewById(R.id.checkfriends_btn);
        myTimeTableBtn= findViewById(R.id.mytimetable_btn);

        checkFriendsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent = new Intent(MainActivity.this, CheckFriendsActivity.class);
                startActivity(intent);
            }
        });
        compareBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent = new Intent(MainActivity.this, CompareActivity.class);
                startActivity(intent);
            }
        });
        myTimeTableBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent = new Intent(MainActivity.this, TimeChartActivity.class);
                startActivity(intent);
            }
        });
        // 뷰 초기화
//        rv_friends = findViewById(R.id.rv_friends);
//
        // 친구 목록
//        friendsList = new ArrayList<>();
//        friendsList.add("허상호");
//        friendsList.add("안세림");
//        friendsList.add("이정수");
        // 이부분에서 친구 목록 추가.

//        // 친구 목록을 보여주는 어댑터
//        friendsAdapter = new FriendsAdapter(friendsList, new FriendsAdapter.OnItemClickListener() {
//            @Override
//            public void onItemClick(int position) {
//                // 친구를 클릭하면 Timetable 액티비티로 이동
//                Intent intent = new Intent(MainActivity.this, TimetableActivity.class);
//                intent.putExtra("friendName", friendsList.get(position));  // 친구 이름을 전달합니다.
//                startActivity(intent);
//            }
//        });
//        // 어댑터를 RecyclerView에 연결
//        rv_friends.setAdapter(friendsAdapter);
//        rv_friends.setLayoutManager(new LinearLayoutManager(this));
        }

}
