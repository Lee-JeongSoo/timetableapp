package com.course.timetableapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class CheckFriendsActivity extends AppCompatActivity {
    private static final String TAG = "PersonDatabase";
    FriendsAdapter adapter;
    FriendsDatabase database;
    ArrayList<Friend> result;
    private Button gobackBtn;
    private Button addFriendBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkfriends);

        gobackBtn = findViewById(R.id.goback_btn);
        addFriendBtn = findViewById(R.id.add_friend_btn);
        RecyclerView recyclerView = findViewById(R.id.friends_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // open database
        database = FriendsDatabase.getInstance(this);
        boolean isOpen = database.open();
        if (isOpen) {
            Log.d(TAG, " database is open.");
        } else {
            Log.d(TAG, "database is not open.");
        }

        adapter = new FriendsAdapter();
        recyclerView.setAdapter(adapter);
        result = selectAll();
        adapter.setItems(result);

        gobackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CheckFriendsActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        addFriendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CheckFriendsActivity.this, AddFriendActivity.class);
                startActivity(intent);
            }
        });
    }

    public ArrayList<Friend> selectAll() {
        ArrayList<Friend> result = database.selectAll();
        Toast.makeText(getApplicationContext(), "정보를 조회했습니다.", Toast.LENGTH_LONG).show();
        return result;
    }
}