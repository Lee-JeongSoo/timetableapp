package com.course.timetableapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;


public class TimeTableDatabase {
    public static final String TAG="TimeTableDatabase";
    public static final String DATABASE_NAME = "timetabledatabase.db";
    private final String TABLE_NAME = "TimeTable";

    private static TimeTableDatabase database;
    public static final int DATABASE_VERSION = 1;
    private Context context;
    private SQLiteDatabase db;
    private TimeTableDatabaseHelper dbHelper;

    private TimeTableDatabase(Context context) {
        this.context = context;
    }

    public static TimeTableDatabase getInstance(Context context) { //싱글톤 패턴으로 현재 context를 통해, 현재 앱의 데이터베이스 인스턴스 변수가 한번만 생성되도록 설정
        if (database == null) {
            database = new TimeTableDatabase(context);
        }
        return database;
    }

    public boolean open() {
        println("opening database [" + DATABASE_NAME + "].");
        dbHelper = new TimeTableDatabaseHelper(context);
        db = dbHelper.getWritableDatabase();

        return true;
    }

    public void close() {
        println("closing database [" + DATABASE_NAME + "].");
        db.close();
        database = null;
    }

    //데이터베이스 쿼리의 결과는 cursor로 반환
    public Cursor rawQueary(String SQL) {
        println("\nexecuteQuery called.\n");
        Cursor c1 = null;
        try {
            c1 = db.rawQuery(SQL, null);
            println("cursor count : " + c1.getCount());
        } catch (Exception ex) {
            Log.e(TAG, "Exception in executeQuery", ex);
        }

        return c1;
    }

    //데이터베이스 명령문
    public boolean execSQL(String SQL) {
        println("\nexecute called.\n");

        try {
            Log.d(TAG, "SQL : " + SQL);
            db.execSQL(SQL);
        } catch (Exception ex) {
            Log.e(TAG, "Exception in executeQuery", ex);
            return false;
        }
        return true;
    }

    public class TimeTableDatabaseHelper extends SQLiteOpenHelper {

        public TimeTableDatabaseHelper(Context context)
        {
            super(context,DATABASE_NAME,null,DATABASE_VERSION);
        }
        @Override
        public void onCreate(SQLiteDatabase db) { //앱이 설치 될때 한번만 실행 됨. getWritableDatabase() 를통해서 접근한것임
            println("creating table [" + TABLE_NAME + "].");
            String DROP_SQL="drop table if exists "+TABLE_NAME;
            try{
                db.execSQL(DROP_SQL);
            }catch (Exception ex)
            {
                Log.e(TAG, "Exception in DROP_SQL", ex);
            }

            String CREATE_SQL = "create table " + TABLE_NAME + "("
                    + "_id INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT, "
                    + "USERID INTEGER,"
                    + "NAME VARCHAR(30),"
                    + "MEMO VARCHAR(50) DEFAULT NULL,"
                    + "DAY TEXT,"
                    + "STARTTIME TIME,"
                    + "ENDTIME TIME)";
            try {
                db.execSQL(CREATE_SQL);
            } catch(Exception ex) {
                Log.e(TAG, "Exception in CREATE_SQL", ex);
            }

        }

        public void onOpen(SQLiteDatabase db) { //getWritableDatabase() 를통해서 접근한것이지만,onCreate()접근안하고 onopen을 통하여 db를 연다
            println("opened database [" + DATABASE_NAME + "].");

        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            println("Upgrading database from version " + oldVersion + " to " + newVersion + ".");

            if (oldVersion < 2) {   // version 1

            }
        }
        private void insertRecord(SQLiteDatabase db, int userid, String name, String memo, String day, String starttime, String endtime) {
            try {
                db.execSQL( "insert into " + TABLE_NAME + "(USERID, NAME, MEMO, DAY, STARTTIME, ENDTIME) " +
                        "values ("
                        + userid+ ", '"
                        + name + "', '"
                        + memo + "', '"
                        + day + "', '"
                        + starttime + "', '"
                        + endtime + "');" );
            } catch(Exception ex) {
                Log.e(TAG, "Exception in executing insert SQL.", ex);
            }
        }
    }
    public void insertRecord(int userid, String name, String memo, String day, String starttime, String endtime) {
        try {
            db.execSQL( "insert into " + TABLE_NAME + "(USERID, NAME, MEMO, DAY, STARTTIME, ENDTIME) " +
                    "values ("
                    + userid+ ", '"
                    + name + "', '"
                    + memo + "', '"
                    + day + "', '"
                    + starttime + "', '"
                    + endtime + "');" );
        } catch(Exception ex) {
            Log.e(TAG, "Exception in executing insert SQL.", ex);
        }
    }

    public ArrayList<TimeTable> selectAll(int uid)
    {
        ArrayList<TimeTable>result=new ArrayList<TimeTable>();
        try {
            Cursor cursor = db.rawQuery(
                    "SELECT USERID, NAME, MEMO, DAY, STARTTIME, ENDTIME FROM " + TABLE_NAME+" WHERE USERID = " + uid, null);
            for (int i = 0; i < cursor.getCount(); i++) {
                cursor.moveToNext();
//                Log.d(TAG, "TIMETABLE column key index : "+Integer.toString(cursor.getColumnIndex("_id")));
//                Log.d(TAG, "TIMETABLE column key userid : "+Integer.toString(cursor.getColumnIndex("USERID")));
//                Log.d(TAG, "TIMETABLE column key name : "+Integer.toString(cursor.getColumnIndex("NAME")));
//                Log.d(TAG, "TIMETABLE column key memo : "+Integer.toString(cursor.getColumnIndex("MEMO")));
//                Log.d(TAG, "TIMETABLE column key day : "+Integer.toString(cursor.getColumnIndex("DAY")));
//                Log.d(TAG, "TIMETABLE column key stime : "+Integer.toString(cursor.getColumnIndex("STARTTIME")));
//                Log.d(TAG, "TIMETABLE column key etime : "+Integer.toString(cursor.getColumnIndex("ENDTIME")));
                int userId = cursor.getInt(0);
                String name = cursor.getString(1);
                String memo = cursor.getString(2);
                String day = cursor.getString(3);
                String starttime = cursor.getString(4);
                String endtime = cursor.getString(5);

                TimeTable info = new TimeTable(userId, name, memo, day, starttime, endtime);
                result.add(info);
            }

        } catch(Exception ex) {
            Log.e(TAG, "Exception in executing insert SQL.", ex);
        }

        return result;
    }


    private void println(String msg) {
        Log.d(TAG, msg);
    }
}