package com.course.timetableapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class FriendsDatabase {
    public static final String TAG="FriendsDatabase";
    public static final String DATABASE_NAME = "mydatabase.db";
    private final String TABLE_NAME = "Friends";

    private static FriendsDatabase database;
    public static final int DATABASE_VERSION = 2;
    private Context context;
    private SQLiteDatabase db;
    private FirendDatabaseHelper dbHelper;

    private FriendsDatabase(Context context) {
        this.context = context;
    }

    public static FriendsDatabase getInstance(Context context) { //싱글톤 패턴으로 현재 context를 통해, 현재 앱의 데이터베이스 인스턴스 변수가 한번만 생성되도록 설정
        if (database == null) {
            database = new FriendsDatabase(context);
        }
        return database;
    }

    public boolean open() {
        println("opening database [" + DATABASE_NAME + "].");
        dbHelper = new FirendDatabaseHelper(context);
        db = dbHelper.getWritableDatabase();

        return true;
    }

    public void close() {
        println("closing database [" + DATABASE_NAME + "].");
        db.close();
        database = null;
    }

    //데이터베이스 쿼리의 결과는 cursor로 반환
    public Cursor rawQueary(String SQL) {
        println("\nexecuteQuery called.\n");
        Cursor c1 = null;
        try {
            c1 = db.rawQuery(SQL, null);
            println("cursor count : " + c1.getCount());
        } catch (Exception ex) {
            Log.e(TAG, "Exception in executeQuery", ex);
        }

        return c1;
    }

    //데이터베이스 명령문
    public boolean execSQL(String SQL) {
        println("\nexecute called.\n");

        try {
            Log.d(TAG, "SQL : " + SQL);
            db.execSQL(SQL);
        } catch (Exception ex) {
            Log.e(TAG, "Exception in executeQuery", ex);
            return false;
        }
        return true;
    }

    public class FirendDatabaseHelper extends SQLiteOpenHelper {

        public FirendDatabaseHelper(Context context)
        {
            super(context,DATABASE_NAME,null,DATABASE_VERSION);
        }
        @Override
        public void onCreate(SQLiteDatabase db) { //앱이 설치 될때 한번만 실행 됨. getWritableDatabase() 를통해서 접근한것임
            println("creating table [" + TABLE_NAME + "].");
            String DROP_SQL="drop table if exists "+TABLE_NAME;
            try{
                db.execSQL(DROP_SQL);
            }catch (Exception ex)
            {
                Log.e(TAG, "Exception in DROP_SQL", ex);
            }

            String CREATE_SQL = "create table " + TABLE_NAME + "("
                    + "_id INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT, "
                    + "NAME VARCHAR(30),"
                    + "TIMETABLEID INTEGER DEFAULT NULL)";
            try {
                db.execSQL(CREATE_SQL);
            } catch(Exception ex) {
                Log.e(TAG, "Exception in CREATE_SQL", ex);
            }

//                insertRecord(db, "이름",null);
//                insertDefaultUser(db);

        }
        private void insertDefaultUser(SQLiteDatabase db) {
            String name = "기본 사용자";
            //todo 여기 고칠것.
            String timetableID = "기본 시간표 ID";

            ContentValues values = new ContentValues();
            values.put("NAME", name);
            values.put("TIMETABLEID", timetableID);

            db.insert(TABLE_NAME, null, values);
        }
        public void onOpen(SQLiteDatabase db) { //getWritableDatabase() 를통해서 접근한것이지만,onCreate()접근안하고 onopen을 통하여 db를 연다
            println("opened database [" + DATABASE_NAME + "].");

        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            println("Upgrading database from version " + oldVersion + " to " + newVersion + ".");

            if (oldVersion < 2) {   // version 1

            }
        }
        private void insertRecord(SQLiteDatabase db, String name, String timetableID) {
            try {
                db.execSQL( "insert into " + TABLE_NAME + "(NAME, TIMETABLEID) values ('" + name + "', " + timetableID + ");" );
            } catch(Exception ex) {
                Log.e(TAG, "Exception in executing insert SQL.", ex);
            }
        }
    }
    public void insertRecord(String name, String timetableID) {
        try {
            db.execSQL( "insert into " + TABLE_NAME + "(NAME, TIMETABLEID) values ('" + name + "', " + timetableID + ");" );
        } catch(Exception ex) {
            Log.e(TAG, "Exception in executing insert SQL.", ex);
        }
    }

    public ArrayList<Friend> selectAll()
    {
        ArrayList<Friend>result=new ArrayList<Friend>();
        try {
            Cursor cursor = db.rawQuery("SELECT _id, NAME,TIMETABLEID FROM " + TABLE_NAME, null);
            for (int i = 0; i < cursor.getCount(); i++) {
                cursor.moveToNext();
                /*
                Log.d(TAG, "friend column key index : "+Integer.toString(cursor.getColumnIndex("_id")));
                Log.d(TAG, "friend column key name : "+Integer.toString(cursor.getColumnIndex("NAME")));
                Log.d(TAG, "friend column key ttid : "+Integer.toString(cursor.getColumnIndex("TIMETABLEID")));
*/
                int idIndex = cursor.getInt(0);
                String name = cursor.getString(1);
                String TTid = cursor.getString(2);

                Friend info = new Friend(idIndex, name, TTid);
                result.add(info);
            }

        } catch(Exception ex) {
            Log.e(TAG, "Exception in executing insert SQL.", ex);
        }

        return result;
    }
    public ArrayList<FriendsCheck> selectAll_()
    {
        ArrayList<FriendsCheck>result=new ArrayList<FriendsCheck>();
        try {
            Cursor cursor = db.rawQuery("SELECT _id, NAME,TIMETABLEID FROM " + TABLE_NAME, null);
            for (int i = 0; i < cursor.getCount(); i++) {
                cursor.moveToNext();
                /*
                Log.d(TAG, "friend column key index : "+Integer.toString(cursor.getColumnIndex("_id")));
                Log.d(TAG, "friend column key name : "+Integer.toString(cursor.getColumnIndex("NAME")));
                Log.d(TAG, "friend column key ttid : "+Integer.toString(cursor.getColumnIndex("TIMETABLEID")));
*/
                int idIndex = cursor.getInt(0);
                String name = cursor.getString(1);
                String TTid = cursor.getString(2);

                FriendsCheck info = new FriendsCheck(idIndex, name, TTid);
                result.add(info);
            }

        } catch(Exception ex) {
            Log.e(TAG, "Exception in executing insert SQL.", ex);
        }

        return result;
    }


    private void println(String msg) {
        Log.d(TAG, msg);
    }
}