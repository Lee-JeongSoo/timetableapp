package com.course.timetableapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class AddNewActivity extends AppCompatActivity {
    private static final String TAG = "TimeTableDatabase";
    private Button gobackBtn;
    private Button saveBtn;
    TimeTableDatabase database;
    ArrayList<TimeTable> result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new);
        gobackBtn = findViewById(R.id.goback_btn);
        saveBtn = findViewById(R.id.save_btn);
        EditText edit_name = findViewById(R.id.name);
        EditText edit_memo = findViewById(R.id.memo);
        Spinner spinner_day = (Spinner)findViewById(R.id.day_spinner);
        Spinner spinner_starthour = (Spinner)findViewById(R.id.start_time_hour);
        Spinner spinner_startminute = (Spinner)findViewById(R.id.start_time_minute);
        Spinner spinner_endhour = (Spinner)findViewById(R.id.end_time_hour);
        Spinner spinner_endminute = (Spinner)findViewById(R.id.end_time_minutes);


        gobackBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (View v){
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent = new Intent(AddNewActivity.this, TimeChartActivity.class);
                startActivity(intent);
            }
        });
        if (database != null) {
            database.close();
            database = null;
        }

        database = TimeTableDatabase.getInstance(this);
        boolean isOpen = database.open();
        if (isOpen) {
            Log.d(TAG, " database is open.");
        } else {
            Log.d(TAG, "database is not open.");
        }
        saveBtn.setOnClickListener(new View.OnClickListener()
        {
            //결과창 페이지 그리기
            @Override
            public void onClick(View v) {
                if (edit_name.getText().toString().equals("")
                        ||edit_name.getText().toString().equals("")
                        ||spinner_day.getSelectedItem().toString().equals("선택해주세요")
                        ||spinner_startminute.getSelectedItem().toString().equals("선택해주세요")
                        ||spinner_starthour.getSelectedItem().toString().equals("선택해주세요")
                        ||spinner_endhour.getSelectedItem().toString().equals("선택해주세요")
                        ||spinner_endminute.getSelectedItem().toString().equals("선택해주세요") )
                    Toast.makeText(getApplicationContext(), "데이터를 다시 입력해주세요", Toast.LENGTH_LONG).show();
                else if (Integer.valueOf(spinner_starthour.getSelectedItem().toString()) >
                        Integer.valueOf(spinner_endhour.getSelectedItem().toString())) {
                    Toast.makeText(getApplicationContext(), "시작시간이 종료시간보다 늦을수 없습니다!", Toast.LENGTH_LONG).show();

                }
                else if (spinner_starthour.getSelectedItem().toString().equals(spinner_endhour.getSelectedItem().toString())&&
                        Integer.valueOf(spinner_startminute.getSelectedItem().toString()) >=
                                Integer.valueOf(spinner_endminute.getSelectedItem().toString())
                        ) {
                    Toast.makeText(getApplicationContext(), "시작시간이 종료시간보다 같거나 늦을수 없습니다!", Toast.LENGTH_LONG).show();

                }else {
                    insert(edit_name.getText().toString(),
                            edit_memo.getText().toString(),
                            spinner_day.getSelectedItem().toString(),
                            spinner_starthour.getSelectedItem().toString()+":"+
                            spinner_startminute.getSelectedItem().toString()+":00",
                            spinner_endhour.getSelectedItem().toString()+":"+
                            spinner_endminute.getSelectedItem().toString()+":00");
                    //result = selectAll();
                    //TODO 시간표호출로 넘어갈떄 출력할 시간표 id를 가져가야함. 이전페이지에서 넘겨받은걸 여기서 갖고있다가 돌아갈때 사용하는걸로 일당ㄴ 하자
                    Intent intent = new Intent(AddNewActivity.this, TimeChartActivity.class);

                    startActivity(intent);
                }
            }
        });
    }
    public void insert(String name, String memo, String day, String starttime, String endtime) {
        database.insertRecord(-2,name, memo, day, starttime,endtime);
        //사용자는 -2를 key로 갖는다.
        Toast.makeText(getApplicationContext(), "정보를 추가했습니다.", Toast.LENGTH_LONG).show();
    }

}