package com.course.timetableapp;

public class Friend {
    private int ID;
    private String NAME;
    private String TIMETABLE_ID;

    public Friend(int id, String Name, String TTid){
        this.ID = id;
        this.NAME=Name;
        this.TIMETABLE_ID=TTid;
    }
    public Friend(String Name, String TTid){
        this.NAME=Name;
        this.TIMETABLE_ID=TTid;
    }

    public String getName() {
        return NAME;
    }

    public int getID() {
        return ID;
    }

    public String getTIMETABLE_ID() {
        return TIMETABLE_ID;
    }
}