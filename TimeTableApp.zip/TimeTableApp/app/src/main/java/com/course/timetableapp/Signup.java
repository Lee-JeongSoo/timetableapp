package com.course.timetableapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Signup extends AppCompatActivity {

    private TextView back;
    private EditText signName;
    private EditText signPW;
    private EditText signPW2;
    private Button pwcheckbutton;
    private Button signupbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        initViews();
        // 뒤로가기 텍스트뷰 클릭 리스너 설정
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        // 비밀번호 확인 버튼 클릭 리스너 설정
        pwcheckbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPassword();
            }
        });
        // 회원가입 버튼 클릭 리스너 설정
        signupbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
    }
    private void initViews() {
        back = findViewById(R.id.back);
        signName = findViewById(R.id.signName);
        signPW = findViewById(R.id.signPW);
        signPW2 = findViewById(R.id.signPW2);
        pwcheckbutton = findViewById(R.id.pwcheckbutton);
        signupbutton = findViewById(R.id.signupbutton);
    }
    // 고유번호 일치 검사
    private void checkPassword() {
        String password = signPW.getText().toString().trim();
        String password2 = signPW2.getText().toString().trim();

        if (password.equals(password2)) {
            Toast.makeText(Signup.this, "비밀번호가 일치합니다.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(Signup.this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
        }
    }
    // 회원가입
    private void registerUser() {
        String name = signName.getText().toString().trim();
        String password = signPW.getText().toString().trim();
        String password2 = signPW2.getText().toString().trim();

        // 유효성 검사 후 회원가입 시도
        if(validate(name, password, password2)){
            // 회원가입 성공 토스트 메세지 표시
            Toast.makeText(Signup.this, "회원가입 성공", Toast.LENGTH_SHORT).show();
            // 회원가입 성공 후 로그인 화면으로 이동.
            Intent intent = new Intent(Signup.this, LoginActivity.class);
            finish();
        }
    }
    // 입력값 유효성 검사
    private boolean validate(String name, String password, String password2) {
        if (name.isEmpty()) {
            Toast.makeText(Signup.this, "이름을 입력해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.isEmpty()) {
            Toast.makeText(Signup.this, "고유번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!password.equals(password2)) {
            Toast.makeText(Signup.this, "고유번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
