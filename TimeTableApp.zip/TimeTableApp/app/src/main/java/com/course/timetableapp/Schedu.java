package com.course.timetableapp;

public class Schedu {
    private String name;
    private String memo;
    private String day;
    private String startTime;
    private String endTime;

    public Schedu(String name, String memo, String day, String StartTime, String endTime){
        this.day= day;
        this.name=name;
        this.memo=memo;
        this.startTime=StartTime;
        this.endTime=endTime;
    }
    public Schedu(String name, String day, String StartTime, String endTime){
        this.day= day;
        this.name=name;
        this.startTime=StartTime;
        this.endTime=endTime;
    }
    public Schedu(){}

    public String getDay() {
        return day;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getMemo() {
        return memo;
    }

    public String getName() {
        return name;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public void setName(String name) {
        this.name = name;
    }
}
