package com.course.timetableapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class AddFriendActivity extends AppCompatActivity {
    private static final String TAG = "FriendsDatabase";
    private Button gobackBtn;
    private Button addBtn;
    FriendsDatabase database;
    ArrayList<Friend> result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_friend);
        gobackBtn = findViewById(R.id.goback_btn);
        addBtn = findViewById(R.id.add_btn);
        EditText edit_name=findViewById(R.id.friend_name);

        gobackBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (View v){
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent = new Intent(AddFriendActivity.this, CheckFriendsActivity.class);
                startActivity(intent);
            }
        });

        if (database != null) {
            database.close();
            database = null;
        }

        database = FriendsDatabase.getInstance(this);
        boolean isOpen = database.open();
        if (isOpen) {
            Log.d(TAG, " database is open.");
        } else {
            Log.d(TAG, "database is not open.");
        }

        addBtn.setOnClickListener(new View.OnClickListener() {
            //결과창 페이지 그리기
            @Override
            public void onClick(View v) {
                if (edit_name.getText().toString().equals(""))
                    Toast.makeText(getApplicationContext(), "데이터를 다시 입력해주세요", Toast.LENGTH_LONG).show();
                else {
                    insert(edit_name.getText().toString(),"-1");
                    //result = selectAll();
                    Intent intent = new Intent(AddFriendActivity.this, CheckFriendsActivity.class);

                    startActivity(intent);
                }
            }

        });



    }
    public void insert(String name, String timetableID) {
        database.insertRecord(name, timetableID);
        Toast.makeText(getApplicationContext(), "정보를 추가했습니다.", Toast.LENGTH_LONG).show();
    }
    public ArrayList<Friend> selectAll() {
        ArrayList<Friend> result = database.selectAll();
        Toast.makeText(getApplicationContext(), "정보를 조회했습니다.", Toast.LENGTH_LONG).show();
        return result;
    }
}