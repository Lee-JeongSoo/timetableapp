package com.course.timetableapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class FriendTimeTableActivity extends AppCompatActivity {
    private static final String TAG = "FriendTimTableActivity";
    TimeTableDatabase database;
    private static final String KEY_USER_ID = "user_id";
    private Button gobackBtn;
    private Button addPlanBtn;
    private Button deleteBtn;

    private int userId;
    private String userName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_time_table);

        gobackBtn = findViewById(R.id.goback_btn);
        addPlanBtn = findViewById(R.id.add_plan_btn);
        deleteBtn = findViewById(R.id.delete_btn);
        TextView textView = findViewById(R.id.Username);


        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            // Bundle에서 사용자의 key 값을 추출
            userId = extras.getInt(KEY_USER_ID);
            userName = extras.getString("user_name");
        }
        Log.d(TAG, "input extras:" + userId);
        if (database != null) {
            database.close();
            database = null;
        }

        textView.setText(userName);

        database = TimeTableDatabase.getInstance(this);
        boolean isOpen = database.open();
        if (isOpen) {
            Log.d(TAG, " database is open.");
        } else {
            Log.d(TAG, "database is not open.");
        }
        //todo 친구 를 선택했을떄 사용자 id가 0으로 나오네
        Log.d(TAG, Integer.toString(userId));
        gobackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent = new Intent(FriendTimeTableActivity.this, CheckFriendsActivity.class);

                startActivity(intent);
            }
        });
        addPlanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent = new Intent(FriendTimeTableActivity.this, AddNewFriendverActivity.class);
                intent.putExtra("user_id", userId);
                startActivity(intent);
            }
        });
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //todo 사용자를 삭제하는 프로세스 만들기
                Intent intent = new Intent(FriendTimeTableActivity.this, CheckFriendsActivity.class);
                startActivity(intent);
            }
        });

        loadTimetable();

    }
    private void loadTimetable() {
        // 시간표 데이터를 가져오는 로직을 구현합니다.
        //기본 사용자는 -2를 키로 한다.
        ArrayList<TimeTable> timetableList = database.selectAll(userId);

        if(timetableList==null) return;
        // 가져온 시간표 데이터를 텍스트뷰에 설정합니다.
        for (TimeTable timetable : timetableList) {
            String textViewDayId = null;
            // 시간과 요일에 해당하는 텍스트뷰 ID를 찾습니다. (예: R.id.monday_9am)
            switch(timetable.getDay()) {
                case "월":
                    textViewDayId = "monday";
                    break;
                case "화":
                    textViewDayId = "tuesday";
                    break;
                case "수":
                    textViewDayId = "wednesday";
                    break;
                case "목":
                    textViewDayId = "thursday";
                    break;
                case "금":
                    textViewDayId = "friday";
                    break;
                case "토":
                    textViewDayId = "seturday";
                    break;
                case "일":
                    textViewDayId = "sunday";
                    break;
            }
            int hour = Integer.valueOf(timetable.getStarttime());
            while(hour<Integer.valueOf(timetable.getEndtime())) {
                String textViewId = textViewDayId + Integer.toString(hour);
                //Log.d("CHECKVALUE", textViewId+" "+timetable.getStarttime()+timetable.getEndtime());
                int resId = getResources().getIdentifier(textViewId, "id", getPackageName());

                if (resId != 0) {
                    TextView textView = findViewById(resId);
                    //textView.setText(timetable.getName());
                    textView.setBackgroundResource(R.drawable.fill_cell);
                }
                if(hour%100==30) hour+=70;
                else hour +=30;
            }
        }
    }
}