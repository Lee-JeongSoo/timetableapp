package com.course.timetableapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EditTimetableActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_timetable);
    }
}