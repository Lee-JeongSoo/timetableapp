package com.course.timetableapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CompareFriendsAdapter extends RecyclerView.Adapter<CompareFriendsAdapter.ViewHolder> {
    public static final String TAG = "FriendsAdapter";
    ArrayList<FriendsCheck> items = new ArrayList<>();

    public void setItems(ArrayList<FriendsCheck> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View itemView = inflater.inflate(R.layout.comparefriend_item_layout, viewGroup, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        FriendsCheck item = items.get(position);
        viewHolder.setItem(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView text_name;
        CheckBox checkBox;

        public ViewHolder(View itemView) {
            super(itemView);
            text_name = itemView.findViewById(R.id.name_text);
            checkBox = itemView.findViewById(R.id.checkbox);

            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        FriendsCheck friend = items.get(pos);
                        friend.setSelected(checkBox.isChecked());
                        Log.d(TAG, Integer.toString(pos));
                        Log.d(TAG, Integer.toString(friend.getID()));
                        Log.d(TAG, friend.getName());
                        Log.d(TAG, " 선택여부 : " + Boolean.toString(friend.isSelected()));
                    }
                }
            });
        }

        public void setItem(FriendsCheck item) {
            text_name.setText(item.getName());
            checkBox.setChecked(item.isSelected());
        }
    }
}
