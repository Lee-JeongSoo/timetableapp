//package com.course.timetableapp;
//
//import android.content.Context;
//import android.database.Cursor;
//import android.database.sqlite.SQLiteDatabase;
//import android.database.sqlite.SQLiteOpenHelper;
//import android.util.Log;
//
//import java.util.ArrayList;
//
//public class TimeTableListDatabase {
//    public static final String TAG = "TimeTableListDatabase";
//    public static final String DATABASE_NAME = "timetablelistdatabase.db";
//    private final String TABLE_NAME = "TimeTableList";
//
//    private static TimeTableListDatabase database;
//    public static final int DATABASE_VERSION = 1;
//    private Context context;
//    private SQLiteDatabase db;
//    private TimeTableListDatabaseHelper dbHelper;
//
//    private TimeTableListDatabase(Context context) {
//        this.context = context;
//    }
//
//    public static TimeTableListDatabase getInstance(Context context) {
//        if (database == null) {
//            database = new TimeTableListDatabase(context);
//        }
//        return database;
//    }
//
//    public boolean open() {
//        println("opening database [" + DATABASE_NAME + "].");
//        dbHelper = new TimeTableListDatabaseHelper(context);
//        db = dbHelper.getWritableDatabase();
//
//        return true;
//    }
//
//    public void close() {
//        println("closing database [" + DATABASE_NAME + "].");
//        db.close();
//        database = null;
//    }
//
//    public Cursor rawQuery(String SQL) {
//        println("\nexecuteQuery called.\n");
//        Cursor cursor = null;
//        try {
//            cursor = db.rawQuery(SQL, null);
//            println("cursor count: " + cursor.getCount());
//        } catch (Exception ex) {
//            Log.e(TAG, "Exception in executeQuery", ex);
//        }
//
//        return cursor;
//    }
//
//    public boolean execSQL(String SQL) {
//        println("\nexecute called.\n");
//
//        try {
//            Log.d(TAG, "SQL: " + SQL);
//            db.execSQL(SQL);
//        } catch (Exception ex) {
//            Log.e(TAG, "Exception in executeQuery", ex);
//            return false;
//        }
//        return true;
//    }
//
//    public class TimeTableListDatabaseHelper extends SQLiteOpenHelper {
//        public TimeTableListDatabaseHelper(Context context) {
//            super(context, DATABASE_NAME, null, DATABASE_VERSION);
//        }
//
//        @Override
//        public void onCreate(SQLiteDatabase db) {
//            println("creating table [" + TABLE_NAME + "].");
//            String DROP_SQL = "DROP TABLE IF EXISTS " + TABLE_NAME;
//            try {
//                db.execSQL(DROP_SQL);
//            } catch (Exception ex) {
//                Log.e(TAG, "Exception in DROP_SQL", ex);
//            }
//
//            String CREATE_SQL = "CREATE TABLE " + TABLE_NAME + "("
//                    + "_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "
//                    + "TIMETABLE_CONTENTS TEXT)";
//
//            try {
//                db.execSQL(CREATE_SQL);
//            } catch (Exception ex) {
//                Log.e(TAG, "Exception in CREATE_SQL", ex);
//            }
//
//            insertRecord(db, "Timetable contents here");
//        }
//
//        public void onOpen(SQLiteDatabase db) {
//            println("opened database [" + DATABASE_NAME + "].");
//        }
//
//        @Override
//        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//            println("Upgrading database from version " + oldVersion + " to " + newVersion + ".");
//
//            if (oldVersion < 2) {
//                // Upgrade code for version 1 to 2
//            }
//        }
//
//        private void insertRecord(SQLiteDatabase db, String contents) {
//            try {
//                db.execSQL("INSERT INTO " + TABLE_NAME + "(TIMETABLE_CONTENTS) VALUES ('" + contents + "')");
//            } catch (Exception ex) {
//                Log.e(TAG, "Exception in executing insert SQL.", ex);
//            }
//        }
//    }
//
//    public void insertRecord(String contents) {
//        try {
//            db.execSQL("INSERT INTO " + TABLE_NAME + "(TIMETABLE_CONTENTS) VALUES ('" + contents + "')");
//        } catch (Exception ex) {
//            Log.e(TAG, "Exception in executing insert SQL.", ex);
//        }
//    }
//
//    public ArrayList<String> selectAll() {
//        ArrayList<String> result = new ArrayList<>();
//        try {
//            Cursor cursor = db.rawQuery("SELECT TIMETABLE_CONTENTS FROM " + TABLE_NAME, null);
//            while (cursor.moveToNext()) {
//                String contents = cursor.getString(0);
//                result.add(contents);
//            }
//        } catch (Exception ex) {
//            Log.e(TAG, "Exception in executing insert SQL.", ex);
//        }
//        return result;
//    }
//
//    private void println(String msg) {
//        Log.d(TAG, msg);
//    }
//}
