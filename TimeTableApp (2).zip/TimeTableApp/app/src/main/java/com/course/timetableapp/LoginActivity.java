package com.course.timetableapp;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

//로그인 화면
public class LoginActivity extends AppCompatActivity {

    private EditText et_username;
    private EditText et_unique_id;
    private Button btn_login;
    private TextView btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initViews();
        // 로그인 버튼 클릭 리스너 설정
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 사용자 이름과 고유번호 입력값 얻기
                String username = et_username.getText().toString().trim();
                String unique_id = et_unique_id.getText().toString().trim();
                // 유효성 검사 후 로그인
                if (validate(username, unique_id)) {
                    loginUser(username, unique_id);
                }
            }
        });

        // 회원가입 텍스트뷰 클릭 리스너 설정
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 회원가입 페이지로 이동
                Intent intent = new Intent(LoginActivity.this, Signup.class);
                startActivity(intent);
            }
        });
    }

    private void initViews() {
        et_username = findViewById(R.id.et_username);
        et_unique_id = findViewById(R.id.et_unique_id);
        btn_login = findViewById(R.id.btn_login);
        btnRegister = findViewById(R.id.btnRegister);
    }

    // 입력값 유효성 검사 메서드
    private boolean validate(String username, String unique_id) {
        // 이름이 빈 경우 에러 메세지 표시
        if (username.isEmpty()) {
            Toast.makeText(LoginActivity.this, "이름을 입력해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        }
        // 고유 번호가 빈 경우 에러 메세지 표시
        if (unique_id.isEmpty()) {
            Toast.makeText(LoginActivity.this, "고유번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void loginUser(String username, String unique_id) {
        if (username.equals("admin") && unique_id.equals("1234")) {
            // 로그인 성공 토스트 메시지 표시
            Toast.makeText(LoginActivity.this, "로그인 성공", Toast.LENGTH_SHORT).show();

            // 로그인 성공 후 메인 액티비티로 이동
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            // 로그인 액티비티 종료
            finish();
        } else {
            // 로그인 실패 토스트 메시지 표시
            Toast.makeText(LoginActivity.this, "로그인 실패. 사용자 이름이나 고유번호를 확인해주세요.", Toast.LENGTH_SHORT).show();
        }
    }
}
