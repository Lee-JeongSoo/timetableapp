
package com.course.timetableapp;

import android.os.Parcel;
import android.os.Parcelable;

public class FriendsCheck implements Parcelable {
    private int ID;
    private String NAME;
    private String TIMETABLE_ID;
    private boolean isSelected;

    public FriendsCheck(int id, String Name, String TTid){
        this.ID = id;
        this.NAME=Name;
        this.TIMETABLE_ID=TTid;
        this.isSelected = false;
    }
    public FriendsCheck(String Name, String TTid){
        this.NAME=Name;
        this.TIMETABLE_ID=TTid;
        this.isSelected = false;
    }

    public String getName() {
        return NAME;
    }

    public int getID() {
        return ID;
    }

    public String getTIMETABLE_ID() {
        return TIMETABLE_ID;
    }
    // 선택 여부 설정
    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

    // 선택 여부 반환
    public boolean isSelected() {
        return isSelected;
    }
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(ID);
        dest.writeString(NAME);
        dest.writeString(TIMETABLE_ID);
        dest.writeByte((byte) (isSelected ? 1 : 0));
    }

    protected FriendsCheck(Parcel in) {
        ID = in.readInt();
        NAME = in.readString();
        TIMETABLE_ID = in.readString();
        isSelected = in.readByte() != 0;
    }

    public static final Creator<FriendsCheck> CREATOR = new Creator<FriendsCheck>() {
        @Override
        public FriendsCheck createFromParcel(Parcel in) {
            return new FriendsCheck(in);
        }

        @Override
        public FriendsCheck[] newArray(int size) {
            return new FriendsCheck[size];
        }
    };


}

