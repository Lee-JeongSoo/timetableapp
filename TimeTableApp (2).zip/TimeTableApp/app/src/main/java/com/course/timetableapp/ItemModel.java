package com.course.timetableapp;

public class ItemModel {
    private String itemName;
    private boolean isSelected;

    public ItemModel(String itemName) {
        this.itemName = itemName;
        this.isSelected = false;
    }

    public String getItemName() {
        return itemName;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}