package com.course.timetableapp;

import java.util.ArrayList;

public class TimeTable {
    private String id ="-1;";
    private ArrayList<Schedu> timetable;
    private int userId;
    private String name;
    private String memo;
    private String day;
    private String starttime;
    private String endtime;

    public TimeTable(int userId, String name, String memo, String day, String starttime, String endtime){
        this.userId = userId;
        this.name = name;
        this.memo = memo;
        this.day = day;
        this.starttime = starttime;
        this.endtime= endtime;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getMemo() {
        return memo;
    }

    public String getDay() {
        return day;
    }

    public String getName() {
        return name;
    }

    public String getStarttime() {
        String hour = starttime.substring(0,2);
        String minute = starttime.substring(3,5);

        return hour+minute;
    }

    public String getEndtime() {
        String hour = endtime.substring(0,2);
        String minute = endtime.substring(3,5);

        return hour+minute;
    }
    public String getStarttime_() {
        String hour = starttime.substring(0,2);
        String minute = starttime.substring(3,5);

        return hour+":"+minute+":00";
    }

    public String getEndtime_() {
        String hour = endtime.substring(0,2);
        String minute = endtime.substring(3,5);

        return hour+":"+minute+":00";
    }


    public void setMemo(String memo) {
        this.memo = memo;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public void addSchedule(Schedu sc){
        timetable.add(sc);
    }


//Todo 삭제기능 구현할것

//    public void deleteSchedule(String name){
//
//    }
}
