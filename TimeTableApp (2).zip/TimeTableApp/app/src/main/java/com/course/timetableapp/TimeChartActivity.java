package com.course.timetableapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class TimeChartActivity extends AppCompatActivity {
    private static final String TAG = "TimeTableDatabase";
    private Button gobackBtn;
    private Button addPlanBtn;
    TimeTableDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_time_chart);

        gobackBtn = findViewById(R.id.goback_btn);
        addPlanBtn = findViewById(R.id.add_plan_btn);

        gobackBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (View v){
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent = new Intent(TimeChartActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        addPlanBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (View v){
                // EditTimetableActivity로 이동하는 코드를 여기에 작성하세요.
                Intent intent = new Intent(TimeChartActivity.this, AddNewActivity.class);
                startActivity(intent);
            }
        });
        if (database != null) {
            database.close();
            database = null;
        }

        database = TimeTableDatabase.getInstance(this);
        boolean isOpen = database.open();
        if (isOpen) {
            Log.d(TAG, " database is open.");
        } else {
            Log.d(TAG, "database is not open.");
        }
        loadTimetable();

    }
    private void loadTimetable() {
        // 시간표 데이터를 가져오는 로직을 구현합니다.
        //기본 사용자는 -2를 키로 한다.
        ArrayList<TimeTable> timetableList = database.selectAll(-2);

        if(timetableList==null) return;
        // 가져온 시간표 데이터를 텍스트뷰에 설정합니다.
        for (TimeTable timetable : timetableList) {
            String textViewDayId = null;
            // 시간과 요일에 해당하는 텍스트뷰 ID를 찾습니다. (예: R.id.monday_9am)
            switch(timetable.getDay()) {
                case "월":
                    textViewDayId = "monday";
                    break;
                case "화":
                    textViewDayId = "tuesday";
                    break;
                case "수":
                    textViewDayId = "wednesday";
                    break;
                case "목":
                    textViewDayId = "thursday";
                    break;
                case "금":
                    textViewDayId = "friday";
                    break;
                case "토":
                    textViewDayId = "seturday";
                    break;
                case "일":
                    textViewDayId = "sunday";
                    break;
            }
            int hour = Integer.valueOf(timetable.getStarttime());
            while(hour<Integer.valueOf(timetable.getEndtime())) {
                String textViewId = textViewDayId + Integer.toString(hour);
                Log.d("CHECKVALUE", textViewId+" "+timetable.getStarttime()+timetable.getEndtime());
                int resId = getResources().getIdentifier(textViewId, "id", getPackageName());

                if (resId != 0) {
                    TextView textView = findViewById(resId);
                    //textView.setText(timetable.getName());
                    textView.setBackgroundResource(R.drawable.fill_cell);
                }
                if(hour%100==30) hour+=70;
                else hour +=30;
            }
        }
    }
}