package com.course.timetableapp;

import java.util.ArrayList;

public interface OnDatabaseCallback {
    public void insert(String name, String author);
    public ArrayList<Friend> selectAll();
}