package com.course.timetableapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CompareFriendsAdapter extends RecyclerView.Adapter<CompareFriendsAdapter.ViewHolder> {
    public static final String TAG = "FriendsAdapter";
    ArrayList<FriendsCheck> items = new ArrayList<>();
    TimeTableDatabase database;

    public void setItems(ArrayList<FriendsCheck> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View itemView = inflater.inflate(R.layout.comparefriend_item_layout, viewGroup, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        FriendsCheck item = items.get(position);
        viewHolder.setItem(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView text_name;
        CheckBox checkBox;
        TextView remain_time;

        int userId;

        public ViewHolder(View itemView) {
            super(itemView);
            text_name = itemView.findViewById(R.id.name_text);
            checkBox = itemView.findViewById(R.id.checkbox);
            remain_time = itemView.findViewById(R.id.remain_time);

            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        FriendsCheck friend = items.get(pos);
                        friend.setSelected(checkBox.isChecked());
                        Log.d(TAG, Integer.toString(pos));
                        Log.d(TAG, Integer.toString(friend.getID()));
                        Log.d(TAG, friend.getName());
                        Log.d(TAG, " 선택여부 : " + Boolean.toString(friend.isSelected()));
                    }
                }
            });
        }

        public void setItem(FriendsCheck item) {
            userId = item.getID();

            text_name.setText(item.getName());
            checkBox.setChecked(item.isSelected());
            String remainTime;

            if (database != null && database.open()) {
                // 데이터베이스가 이미 열려있으면 닫습니다.
                database.close();
            }

            database = TimeTableDatabase.getInstance(itemView.getContext());
            boolean isOpen = database.open();
            if (isOpen) {
                Log.d(TAG, "Database is open.");
            } else {
                Log.d(TAG, "Database is not open.");
            }
            remainTime = database.selectAll_(-2, userId);


            String[] timeComponents = remainTime.split(":");
            String hours = timeComponents[0];
            String minutes = timeComponents[1];

            String formattedTime = hours + ":" + minutes;
            Log.d(TAG, "사용자 이름 : "+item.getName());
            Log.d(TAG, "사용자 id : "+userId);
            remain_time.setText(formattedTime);
        }
    }
}
